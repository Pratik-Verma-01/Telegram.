<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">ʀᴇᴘᴏ ғᴇᴀᴛᴜʀᴇs</p>


 ![github card](https://github-readme-stats.vercel.app/api/pin/?username=silicon-developer&repo=Multi-Tasking-Bot&theme=dark) 


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">
  <a href="https://github.com/itz-jeoll"><img src="http://readme-typing-svg.herokuapp.com?color=00FF00&center=true&vCenter=true&multiline=false&lines=HI!+THIS+IS+A+MULTI+BOT+WITH+MANY+FEATURES😀;FORK+ME+AND+DEPLOY+NOW;SUPPORT+US+BY+GIVING+A+STAR⭐;Developed+By+Silicon+Developer;Join+Our+Support+Group+For+Help" alt="UwU">
</p>

### What is this bot ?

This is a pyrogram based telegram bot. AI, Search History, Telegram User ID, Info, telegraph, stickerid, fun, etc....

### Features :🚀

● Advance AI

● Carbon

● Multiple Image Uploading Support 

● Gen Videos

● Gen Wallpaper 

● User Info

● Channel ID

● Forward Message Info

● DC tracker

● Telegraph 🔥

● Image edit & BG remover 🤩

● Fun games

● Font editer

● Sticker Kang ❤️‍🔥

● Sticker to Img convert

● Efficient Script 

<details>
<summary><h3>
- <b> ᴅᴇᴘʟᴏʏᴍᴇɴᴛ ᴍᴇᴛʜᴏᴅs </b>
</h3></summary>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Silicon-Developer/Multi-Tasking-Bot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy On Heroku">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴋᴏʏᴇʙ 」─
</h3>
<p align="center"><a href="https://app.koyeb.com/deploy?type=git&repository=github.com/Silicon-Developer/Multi-Tasking-Bot&branch=main&name=main">
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy On Koyeb">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 」─
</h3>
<p align="center"><a href="https://railway.app/deploy?template=https://github.com/Silicon-Developer/Multi-Tasking-Bot"">
     <img height="45px" src="https://railway.app/button.svg">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴇɴᴅᴇʀ 」─
</h3>
<p align="center"><a href="https://render.com/deploy?repo=https://github.com/Silicon-Developer/Multi-Tasking-Bot">
<img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render">
</a></p> 
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴠᴘs 」─
</h3>
<p>
<pre>
git clone https://github.com/Silicon-Developer/Multi-Tasking-Bot.git
# Install Packages
pip3 install -U -r requirements.txt
Edit info.py with variables as given below then run bot
python3 bot.py
</pre>
</p>
</details>

<h3>「 ᴄʀᴇᴅɪᴛs 」
</h3>

- <b>[Sɪʟɪᴄoɴ Bᴏᴛᴢ](https://t.me/Silicon_Bot_Update)</b> -Everything
- <b>Jeol</b> -Base Repo


<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">



## Support & Updates 
<a href="https://t.me/Silicon_Botz"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/Silicon_Bot_Update"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

#People Who Helped Me

• Subaru
• Mr.Spidy
• And My All Team
